import pkg from 'aws-sdk';
const { SQS } = pkg;

const sqsClient = new SQS();

export const sendSQSBatchMessage = async (messages) => {
    const params = {
        Entries: messages,
        QueueUrl: process.env.SQS_QUEUE_URL
    }
    await sqsClient.sendMessageBatch(params).promise();
}